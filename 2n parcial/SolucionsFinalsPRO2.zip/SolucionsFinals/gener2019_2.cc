Arbre arbre_maxims(){
	Arbre a;
	if(primer_node != NULL){
		T x;
		a.primer_node = i_arbre_maxims(primer_node,x);
	}
	else a.primer_node = NULL;
	return a;
}

node* i_arbre_maxims(node* n, T &max){
	node* p = new node;
	if(n->segE == NULL){
		max = n->info;
		p->segE = p->segD = nullptr;
	}
	else{
		T maxe,maxd;
		p->segE = i_arbre_maxims(n->segE,maxe);
		p->segD = i_arbre_maxims(n->segE,maxd);
		max = max(n->info,max(maxe,maxd));
	}
	p->info = max;
	return p;
}