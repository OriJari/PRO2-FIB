void esborrar_tots(const T& x){
	node_llista* n = prim;
	node_llista* aux;
	while(n != NULL){
		if(n->info == x){
			//si es el primer, actualitzem el primer, si no, el saltem
			if(n->ant != NULL) (n->ant)->seg = n->seg;
			else prim = n->seg;
			//si es l'ultim, actualitzem l'ultim, si no, fem el salt anterior
			if(n->seg != NULL) (n->seg)->ant = n->ant;
			else ult = n->ant;
			aux = n->seg;
			delete n;
			n = aux;
		}
		else n = n->seg;
	}
}