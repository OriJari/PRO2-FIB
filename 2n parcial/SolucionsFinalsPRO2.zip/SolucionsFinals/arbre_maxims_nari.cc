ArbreNari ArbreNari::arbre_max() const{
	ArbreNari a(N);
	a.prim = i_arbre_max(prim);
	return a;

}

node* i_arbre_max(node* n,int &max) const{
	node* p;
	if(n == NULL) p = NULL; // :)
	else {
		bool fulla = true;
		for(int i = 0; i < N; ++i){
			if(n->seg[i] == NULL) fulla = false; 
		}

		p = new node;
		p->seg = vector<node*>(N,NULL);
		if(fulla) p->info = max = n->info;
		else{
			int maxh;
			max = n->info;
			for(int i = 0; i < N; ++i){
				p->seg[i] = i_arbre_max(n->seg[i],maxh);
				if(maxh > max) max = maxh;
			}
			p->info = max;
		}
	}

	return p;
}
