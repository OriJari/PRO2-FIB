ArbreNari ArbreNari::arbre_altures() const{
	ArbreNari a(N);
	int altura;
	a.prim = i_arbre_altures(prim,altura);
	return a;
}

node* i_arbre_altures(node* n,int &altura) const{
	node* p;
	if(n == NULL){
		p = NULL;
		altura = 0;
	} 
	else {
		bool fulla = true;
		for(int i = 0; i < N; ++i){
			if(n->seg[i] == NULL) fulla = false; 
		}

		p = new node;
		p->seg = vector<node*>(N,NULL);
		if(fulla) p->info = 1;
		else{
			int max,h;
			p->seg[0] = i_arbre_altures(n->seg[0],altura);
			for(int i = 1; i < N; ++i){
				p->seg[i] = i_arbre_altures(n->seg[i],h);
				if(h > altura) altura = h;
			}
			++altura;
			p->info = altura;
		}
	}

	return p;
}
