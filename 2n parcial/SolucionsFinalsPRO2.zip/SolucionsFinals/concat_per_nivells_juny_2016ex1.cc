void transferir(Llista<T> &dest){
	if(act == prim) act = prim->seg;
	prim->ant = dest.ult;
	if(dest.prim != NULL) dest.ult->seg = prim;
	else dest.prim = prim;
	dest.ult = prim;
	prim = prim->seg;
	if(prim == NULL) ult = NULl;
	else prim->ant = NULL;
	dest.ult->seg = NULL;
	--longitud;
	++dest.longitud;
}

void concat_per_nivells(vector<Llista<T> > &v){
	bool alguna_no_buida = true;
	while(alguna_no_buida){
		alguna_no_buida = false;
		for(int i = 0; i < v.size(); ++i){
			if(v[i].prim != NULL) alguna_no_buida = true;
			v[i].transferir(*this);
		}
	}
}



