void nullify(){
	primer_node = NULL;
	ultim_node = NULL;
	act = NULL;
	longitud = 0;
}

static node_llista* search(node_llista* p, const T& x){
	while(p != NULL){
		if(p->info == x) return p;
		p = p->seg;
	}
	return NULL;
}

void splice(const T& x, Llista &l2){
	if(l2.primer_node != nullptr){
		node_llista* n = primer_node;
		node_llista* px = search(n,x);
		if(px != nullptr){
			if(px->ant != nullptr) px->ant->seg = l2.primer_node;
			else primer_node = l2.primer_node;
			l2.ultim_node->seg = px;
			l2.primer_node->ant = px->ant;
			px->ant = l2.ultim_node;
			longitud += l2.longitud;
		}
		else{
			if(primer_node != nullptr){
				ultim_node->seg = l2.primer_node;
				l2.primer_node->ant = ultim_node;
				ultim_node = l2.ultim_node;
				longitud += l2.longitud;
			}	
			else{
				primer_node = l2.primer_node;
				ultim_node = l2.ultim_node;
				longitud = l2.longitud;
			}
		}
		l2.nullify();

	}
}