int ArbreNari::altura() const{
	return i_altura(prim);
}

int i_altura(node* n){
	int h;
	if(n == NULL) h = 0;
	else{
		h = i_altura(n->seg[0]);
		for(int i = 1; i < N; ++i){
			int hh = i_altura(n->seg[i]);
			if(hh > h) h = hh;
		}
		++h;
	}
	return h;
}