void trams(vector<Llista> &v){
	if(primer != NULL){
		Llista l;
		l.primer = primer;
		l.ultim = primer;
		l.act = primer;
		l.longitud = 1;
		node* n = primer->seg;
		while(n != NULL){
			if(n->info < n->ant->info){
				l.ultim->seg = NULL;
				v.push_back(l);
				l = Llista();
				n->ant = NULL;
				l.primer = n;
				l.act = n;
				l.longitud = 1;
			}
			else{
				++l.longitud;
			}
			l.ultim = n;
			n = n->seg;
		}
	}
	primer = NULL;
	ultim = NULL;
	longitud = 0;
}